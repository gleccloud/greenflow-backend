import { Code2 } from 'lucide-react';

export function Documentation() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">API Documentation</h1>
        <p className="text-slate-600 mt-2">
          Comprehensive API reference with interactive examples
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-3">
          <div className="bg-white rounded-xl p-8 shadow-sm border border-slate-200">
            <div className="flex items-center gap-4 mb-6">
              <Code2 className="w-12 h-12 text-emerald-600" />
              <div>
                <h2 className="text-2xl font-bold text-slate-900">API Console</h2>
                <p className="text-slate-600">
                  Interactive API explorer and documentation
                </p>
              </div>
            </div>
            <p className="text-slate-700 mb-4">
              This section will contain full API documentation with Swagger/OpenAPI integration,
              interactive examples, and code samples in multiple languages. Coming in Phase 3.
            </p>
            <button className="px-6 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors font-medium">
              View Swagger API
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
